import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step-home',
  templateUrl: './step-home.component.html',
  styleUrls: ['./step-home.component.css']
})
export class StepHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
