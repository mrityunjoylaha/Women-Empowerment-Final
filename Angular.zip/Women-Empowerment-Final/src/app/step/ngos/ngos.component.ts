import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngos',
  templateUrl: './ngos.component.html',
  styleUrls: ['./ngos.component.css']
})
export class NgosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
