import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-sectors',
  templateUrl: './training-sectors.component.html',
  styleUrls: ['./training-sectors.component.css']
})
export class TrainingSectorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
